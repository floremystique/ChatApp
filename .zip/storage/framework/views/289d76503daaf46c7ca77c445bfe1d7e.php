<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
      html, body { height: 100%; }
      body { overflow: hidden; }
    </style>

</head>

<body class="font-sans antialiased bg-gray-50 no-overscroll">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\xampp3\htdocs\ChatApp\laravel\resources\views/layouts/spa.blade.php ENDPATH**/ ?>