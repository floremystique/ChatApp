<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto py-8 space-y-4">
        <h1 class="text-xl font-bold">Broadcast Test</h1>

        <div class="p-3 rounded bg-gray-100 text-sm">
            Open this page in <b>two tabs</b>. Click “Fire event” in one tab.
            The other tab should receive it instantly.
        </div>

        <button id="fire"
            class="px-4 py-2 rounded bg-purple-600 text-white">
            Fire event
        </button>

        <pre id="log" class="p-3 bg-black text-green-200 rounded text-xs overflow-auto h-64"></pre>
    </div>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <script>
      const log = (m) => {
        const el = document.getElementById('log');
        el.textContent += m + "\n";
        el.scrollTop = el.scrollHeight;
        console.log(m);
      };

      log("Listening on public channel: test-channel");

      function startListener() {
        if (!window.Echo) {
          log("⏳ Echo not ready yet... waiting");
          setTimeout(startListener, 300);
          return;
        }

        log("✅ Echo is ready. Subscribing...");
        window.Echo.channel('test-channel')
          .listen('.test.event', (e) => {
            log("✅ Received: " + JSON.stringify(e));
          });
      }

      startListener();

      document.getElementById('fire').addEventListener('click', async () => {
        log("Firing event...");
        const res = await fetch('/broadcast-test/fire', {
          method: 'POST',
          headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]')?.content || '',
            'Accept': 'application/json'
          }
        });
        log("Fire response: " + res.status);
      });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp3\htdocs\ChatApp\laravel\resources\views/broadcast-test.blade.php ENDPATH**/ ?>