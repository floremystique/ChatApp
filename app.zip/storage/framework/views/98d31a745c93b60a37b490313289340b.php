<div class="bg-white border rounded-2xl overflow-hidden">
    <div class="p-4 border-b">
        <div class="text-base font-semibold">Serious Compatibility</div>
        <div class="text-xs text-gray-500 mt-0.5">Quick questions to improve match quality.</div>
    </div>

    <form method="POST" action="<?php echo e(route('onboarding.quiz.store')); ?>" class="p-4 space-y-4" data-spa-quiz-form>
        <?php echo csrf_field(); ?>

        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-50 rounded-xl p-4">
                <div class="font-semibold text-sm"><?php echo e($q->title); ?></div>
                <?php if($q->subtitle): ?>
                    <div class="text-xs text-gray-500 mt-1"><?php echo e($q->subtitle); ?></div>
                <?php endif; ?>

                <div class="mt-3 space-y-2">
                    <?php $__currentLoopData = $q->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $picked = optional($existing->get($q->id))->match_question_option_id; ?>
                        <label class="flex items-center gap-3 bg-white border rounded-xl px-3 py-2">
                            <input type="radio" name="answers[<?php echo e($q->id); ?>]" value="<?php echo e($opt->id); ?>" class="rounded"
                                   <?php if((int)$picked === (int)$opt->id): echo 'checked'; endif; ?>>
                            <div class="text-sm"><?php echo e($opt->label); ?></div>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="flex justify-end">
            <button type="submit" class="px-5 py-2.5 rounded-full bg-purple-600 text-white text-sm font-semibold hover:bg-purple-700">
                Save
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp3\htdocs\ChatApp\laravel\resources\views/spa/onboarding_quiz_partial.blade.php ENDPATH**/ ?>