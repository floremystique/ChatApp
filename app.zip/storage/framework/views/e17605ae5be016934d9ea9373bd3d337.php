<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-2xl mx-auto py-10">
        <h1 class="text-2xl font-bold mb-6">Profile setup</h1>

        <form method="POST" action="/onboarding" class="space-y-6">
            <?php echo csrf_field(); ?>

            
            <div class="bg-white p-5 rounded shadow">
                <label class="flex items-center gap-2">
                    <input type="checkbox" name="looks_matter" value="1" class="rounded" <?php if(old('looks_matter', $profile->looks_matter ?? false)): echo 'checked'; endif; ?>>
                    <span>Looks matter</span>
                </label>
            </div>

            
            <div class="bg-white p-5 rounded shadow">
                <label class="block font-semibold mb-2">Conversation mode</label>
                <select name="mode" class="w-full rounded border-gray-300">
                    <?php $currentMode = old('mode', $profile->mode ?? 'casual'); ?>
                    <option value="casual" <?php if($currentMode === 'casual'): echo 'selected'; endif; ?>>Casual</option>
                    <option value="friendly" <?php if($currentMode === 'friendly'): echo 'selected'; endif; ?>>Friendly</option>
                    <option value="deep" <?php if($currentMode === 'deep'): echo 'selected'; endif; ?>>Deep</option>
                    <option value="study" <?php if($currentMode === 'study'): echo 'selected'; endif; ?>>Study</option>
                    <option value="inspiring" <?php if($currentMode === 'inspiring'): echo 'selected'; endif; ?>>Inspiring</option>
                    <option value="matchmaking" <?php if($currentMode === 'matchmaking'): echo 'selected'; endif; ?>>Matchmaking</option>
                    <option value="dark" <?php if($currentMode === 'dark'): echo 'selected'; endif; ?>>Dark</option>
                </select>
                <p class="text-sm text-gray-500 mt-2">
                    If you pick matchmaking, you can optionally add DOB for horoscope matching.
                </p>
            </div>

            <input type="date" name="dob" class="w-full rounded border-gray-300"
                value="<?php echo e(old('dob', optional($profile->dob)->format('Y-m-d'))); ?>">

            <input type="text" name="bio" maxlength="120" class="w-full rounded border-gray-300"
                value="<?php echo e(old('bio', $profile->bio)); ?>"
                placeholder="One line about you…">


            
            <div class="bg-white p-5 rounded shadow">
                <label class="block font-semibold mb-3">Tags</label>
                <div class="grid grid-cols-2 gap-2">
                    <?php
                        $selectedTags = collect(old('tags', $profile->tags?->pluck('id')->all() ?? []))->map(fn($v)=>(int)$v);
                    ?>

                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="tags[]" value="<?php echo e($tag->id); ?>" class="rounded"
                                <?php if($selectedTags->contains((int)$tag->id)): echo 'checked'; endif; ?>>
                            <span><?php echo e($tag->name); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <button class="px-4 py-2 bg-black text-white rounded">
                Save & Find Matches
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp3\htdocs\ChatApp\laravel\resources\views/profile/onboarding.blade.php ENDPATH**/ ?>